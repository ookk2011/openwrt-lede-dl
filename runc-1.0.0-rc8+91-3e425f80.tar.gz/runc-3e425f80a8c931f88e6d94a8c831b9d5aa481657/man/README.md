runc man pages
====================

This directory contains man pages for runc in markdown format.

To generate man pages from it, use this command

    ./md2man-all.sh

You will see man pages generated under the man8 directory.

